const redux = require('redux');

const reduxLogger = require('redux-logger');
const logger = reduxLogger.createLogger();
const applyMiddleware = redux.applyMiddleware;



// logging of actions middleware ==> redux-logger

/* action creator - return an action to be dispatched */
let orderMobile = (customerId) => {
    return {
        type: "ORDER_MOBILE" /* action type */,
        customerId: customerId  /* PAYLOAD */
    }
}
// RETURN MOBILE
let returnMobile = (customerId) => {
    return {
        type: "RETURN_MOBILE" /* action type */,
        customerId: customerId  /* PAYLOAD */
    }
}

let orderTelevision = (customerId) => {
    return {
        type: "ORDER_TELEVISION" /* action type */,
        customerId: customerId  /* PAYLOAD */
    }
}
// RETURN MOBILE
let returnTelevision = (customerId) => {
    return {
        type: "RETURN_TELEVISION" /* action type */,
        customerId: customerId  /* PAYLOAD */
    }
}


/* reducer */
let mobileReducer = (state = initialMobileState, action) => {
    switch (action.type) {
        case "ORDER_MOBILE":
            return {
                ...state,
                customerArray: [...state.customerArray, action.customerId],
                noOfMobiles: state.noOfMobiles - 1
            }
        case "RETURN_MOBILE":
            return {
                ...state,
                customerArray: state.customerArray.filter(customerId => customerId !== action.customerId),
                noOfMobiles: state.noOfMobiles + 1
            }
        default: return state
    }
}

let televisionReducer = (state = initialTelevisionState, action) => {
    switch (action.type) {
        case "ORDER_TELEVISION":
            return {
                ...state,
                customerArray: [...state.customerArray, action.customerId],
                noOfTelevision: state.noOfTelevision - 1
            }
        case "RETURN_TELEVISION":
            return {
                ...state,
                customerArray: state.customerArray.filter(customerId => customerId !== action.customerId),
                noOfTelevision: state.noOfTelevision + 1
            }
        default: return state
    }
}

/* intial state */
let initialMobileState = {
    noOfMobiles: 10,
    customerArray: []
}
let initialTelevisionState = {
    noOfTelevision: 30,
    customerArray: []
}

let rootReducer = redux.combineReducers({ mobiles: mobileReducer, television: televisionReducer })

/* store */
let store = redux.createStore(rootReducer, applyMiddleware(logger));
console.log("intial state", store.getState())

// combineReducer

// subscribe to changes
// store.subscribe(() => console.log("updated mobile state", store.getState()))

// dispatching action  - parameter for dispatch function should be the action object

store.dispatch(orderMobile(100))
store.dispatch(orderMobile(200))
store.dispatch(orderMobile(300))
store.dispatch(returnMobile(200))
store.dispatch(orderTelevision("A1001"))
store.dispatch(orderTelevision("A1002"))
store.dispatch(returnTelevision("A1002"))
/* action will be dispatched by components */

