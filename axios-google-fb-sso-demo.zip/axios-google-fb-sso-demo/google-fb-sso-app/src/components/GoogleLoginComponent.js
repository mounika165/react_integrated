import React, { Component, Fragment } from 'react'
import GoogleLogin, { GoogleLogout } from 'react-google-login';

class GoogleLoginCompoment extends Component {

    constructor(props) {
        super(props)

        this.state = {
            name: "",
            email: "",
            profilePictureURL: ""
        }
    }

    responseGoogle = (response) => {
        console.log("login", response)
        this.setState({
            name: response.profileObj.name,
            email: response.profileObj.email,
            profilePictureURL: response.profileObj.imageUrl
        })
    }

    logout = (response) => {
        console.log("logout", response);
        this.setState({ name: "", email: "", profilePictureURL: "" })
    }

    render() {
        return (
            <div>
                {this.state.name ? <Fragment>
                    <h1>{this.state.name}</h1>
                    <h1>{this.state.email}</h1>
                    <img src={this.state.profilePictureURL} alt={this.state.name} />
                    <GoogleLogout
                        clientId="7622948409737-udij0i4r4f0u35dkdhf01r1aa2m8te93.apps.googleusercontent.com"
                        buttonText="Logout"
                        onLogoutSuccess={this.logout}
                    >
                    </GoogleLogout>
                </Fragment> :
                    <GoogleLogin
                        clientId="7622948409737-udij0i4r4f0u35dkdhf01r1aa2m8te93.apps.googleusercontent.com"
                        buttonText="Login"
                        onSuccess={this.responseGoogle}
                        onFailure={this.responseGoogle}
                        cookiePolicy={'single_host_origin'}
                        isSignedIn={true}
                    />
                }

            </div>
        )
    }
}

export default GoogleLoginCompoment
