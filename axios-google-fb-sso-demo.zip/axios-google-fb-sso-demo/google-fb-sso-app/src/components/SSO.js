import axios from "axios";
import React from "react";
class SSO extends React.Component {
    constructor(props) {
        super(props);
        this.state = { result: "", error: "" };
    }
    componentDidMount() {
        this.sso();
    }
    sso() {
        axios
            .get("http://localhost:3080/", { withCredentials: true })
            .then(response => {
                this.setState({
                    result: "   Hi " + response.data.username + "! Your username is fetched from your credentials",
                    error: ""
                });
            })
            .catch(error => {
                if (error.response) {
                    this.setState({ error: error.response.data.message, result: "" });
                } else {
                    this.setState({ error: error.message, result: "" });
                }
            });
    }

    render() {
        return (
            <div className="text">
                {this.state.result
                    ? this.state.result
                    : null}
            </div>
        );
    }
}
export default SSO;
