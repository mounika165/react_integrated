import React, { Component, Fragment } from 'react';

import FacebookLogin from 'react-facebook-login';

// npm install react-facebook-login --save

class FacebookLoginComponent extends Component {

    constructor(props) {
        super(props)

        this.state = {
            isLoggedIn: false,
            userId: '',
            name: '',
            email: '',
            picture: ''
        }
    }

    responseFacebook = (response) => {
        console.log(response);
        this.setState({
            isLoggedIn: true,
            userId: response.userId,
            name: response.name,
            email: response.email,
            pictureUrl: response.picture.data.url
        })
    }


    componentClicked = () => console.log("clicked")


    render() {
        if (this.state.isLoggedIn) {
            return (
                <Fragment>
                    <h1>{this.state.email}</h1>
                    <h1>{this.state.name}</h1>
                    <img src={this.state.pictureUrl} alt={this.state.name} />
                </Fragment>
            )
        }
        else return (
            <div>
                <FacebookLogin
                    appId="945321765905431"
                    autoLoad={true}
                    fields="name,email,picture"
                    onClick={this.componentClicked}
                    callback={this.responseFacebook} />
            </div>
        )
    }
}

export default FacebookLoginComponent
