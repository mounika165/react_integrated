import React, { Component } from 'react'
import axios from 'axios';

export class AddUser extends Component {

    constructor(props) {
        super(props)
        this.state = {
            addUserForm: {
                username: "",
                password: ""
            },
            addedUserData: "",
            usersArray: [],
            username: "",
            userData: "",
            errorMessage: ""
        }
    }

    handleChange = (event) => {
        let name = event.target.name;
        let value = event.target.value;
        let { addUserForm } = this.state
        addUserForm[name] = value;
        this.setState({ addUserForm: addUserForm }, () => {
            // console.log(this.state.addUserForm);
        })
    }

    handleUsernameChange = (event) => {
        this.setState({ username: event.target.value });
    }

    addUser = (event) => {
        event.preventDefault();
        axios.post("http://localhost:2500/addUser", this.state.addUserForm).then(response => {
            // console.log("success", response.data)
            this.setState({ addedUserData: response.data })
        }).catch(error => {
            console.log("error", error)
        })
    }

    fetchUserByName = () => {
        axios.get("http://localhost:2500/getUserByName/" + this.state.username).then(response => {
            this.setState({ userData: response.data })
        }).catch(error => {
            console.log("error", error.response);
            if (error.response) this.setState({ errorMessage: error.response.data.message })
            else this.setState({ errorMessage: error.message })
        })
    }

    // http://localhost:2500//getUserByName/john@gmail.com/john@123
    
    render() {
        return (
            <div>
                <input type="text" value={this.state.username} onChange={this.handleUsernameChange} />
                <button onClick={this.fetchUserByName}>Fetch Users</button>
                {JSON.stringify(this.state.userData)}
                {this.state.errorMessage}
                <form onSubmit={this.addUser}>
                    <label>User name</label>
                    <input type="text" name="username" value={this.state.addUserForm.username}
                        onChange={this.handleChange} />
                    <label>Password</label>
                    <input type="password" name="password" value={this.state.addUserForm.password} onChange={this.handleChange} />
                    <button type="submit">Add User</button>
                </form>
                {this.state.addedUserData.username} <br />
                {this.state.addedUserData.password}
            </div>
        )
    }
}

export default AddUser
