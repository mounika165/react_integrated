import React from 'react';
import './App.css';
// import GoogleLoginCompoment from './components/GoogleLoginComponent';
import FacebookLoginComponent from './components/FacebookLoginComponent';
// import SSO from './components/SSO'
import AddUser from './components/AddUser';

function App() {

  return (
    <div className="App">
      {/* <AddUser /> */}
      <FacebookLoginComponent />
      {/* <GoogleLoginCompoment />
      <SSO /> */}
    </div>
  );
}

export default App;
