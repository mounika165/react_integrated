const express = require('express');
const router = express.Router();
const usersService = require('../service/users');
const setupdb = require('../model/setupdb').setupDB;


router.get('/setupDB', (req, res, next) => {
    setupdb().then(messageObj => {
        res.json(messageObj)
    }).catch(err => next(err))
})

router.get('/getAllUsers', (req, res, next) => {
    usersService.getAllUsers().then(usersArray => {
        res.json(usersArray)
    }).catch(err => next(err))
})


router.post('/addUser', (req, res, next) => {
    usersService.addUser(req.body).then(addedUser => {
        res.json(addedUser)
    }).catch(err => next(err))
})


router.get('/getUserByName/:username', (req, res, next) => {
    let username = req.params.username
    usersService.getUserByName(username).then(userData => {
        res.json(userData)
    }).catch(err => next(err))
})

router.put('/updatePassword', (req, res, next) => {
    usersService.updatePassword(req.body).then(updated => {
        res.json({ "message": "password updated successfully" })
    }).catch(err => next(err))
})


module.exports = router;