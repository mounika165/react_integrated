const usersDB = require('../model/users');

const usersService = {}

usersService.getAllUsers = () => {
    return usersDB.getAllUsers().then(usersArray => {
        if (usersArray) return usersArray
        else {
            let err = new Error('No Users Found!!')
            err.status = 404;
            throw err;
        }
    })
}

usersService.addUser = (userObj) => {
    return usersDB.addUser(userObj).then(addedUser => {
        if (addedUser) return addedUser
        else {
            let err = new Error('User could not be added!!')
            err.status = 500;
            throw err;
        }
    })
}

usersService.getUserByName = (username) => {
    return usersDB.getUserByName(username).then(userData => {
        if (userData) return userData
        else {
            let err = new Error(`No Users Found with username ${username} !!`)
            err.status = 404;
            throw err;
        }
    })
}

usersService.updatePassword = (userObj) => {
    return usersDB.updatePassword(userObj).then(updateStatus => {
        if(updateStatus) return true
        else {
            let err = new Error(`Password update failed!!`)
            err.status = 500;
            throw err;
        }
    })
}


module.exports = usersService;