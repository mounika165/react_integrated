const connection = require('./connection');

usersData = [
    {
        username: "john@gmail.com",
        password: "john@123"
    },
    {
        username: "jack@gmail.com",
        password: "jack@123"
    }
]


exports.setupDB = () => {
    return connection.getUsersCollection().then(userModel => {
        return userModel.deleteMany({}).then(deleted => {
            return userModel.insertMany(usersData).then(insertedData => {
                if (insertedData.length) return { "message": "insertion successful" }
                else throw new Error("setupdb failed")
            })
        })
    })
}