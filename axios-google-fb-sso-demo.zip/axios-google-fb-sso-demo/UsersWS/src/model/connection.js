const mongoose = require('mongoose');


usersSchema = mongoose.Schema({
    username: { type: String, required: true, unique: true },
    password: { type: String, required: true }
})

let connection = {}

mongoose.set('useCreateIndex', true)

connection.getUsersCollection = () => {
    return mongoose.connect("mongodb://localhost:27017/UsersDatabase", { useNewUrlParser: true, useUnifiedTopology: true }).then(db => {
        return mongoose.model('Users', usersSchema)
    }).catch(error => {
        let err = new Error("Could not connect to database");
        err.status = 500;
        throw err;
    })
}

module.exports = connection;