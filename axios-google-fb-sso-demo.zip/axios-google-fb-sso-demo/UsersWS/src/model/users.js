const connection = require('./connection');

const usersDB = {}

usersDB.getAllUsers = () => {
    return connection.getUsersCollection().then(userModel => {
        return userModel.find().then(usersArray => {
            if (usersArray.length) return usersArray
            else return null
        })
    })
}

usersDB.addUser = (userObj) => {
    return connection.getUsersCollection().then(userModel => {
        return userModel.create(userObj).then(insertedUser => {
            if (insertedUser) return insertedUser
            else return null
        })
    })
}

usersDB.getUserByName = (username) => {
    console.log(username);
    
    return connection.getUsersCollection().then(userModel => {
        return userModel.findOne({ username: username }).then(userData => {
            if (userData) return userData
            else return null
        })
    })
}

usersDB.updatePassword = (userObj) => {
    return connection.getUsersCollection().then(userModel => {
        return userModel.updateOne({ username: userObj.username }, { $set: { password: userObj.password } }).then(updateStatus => {
            if (updateStatus.nModified > 0) return true
            else return false
        })
    })
}


module.exports = usersDB