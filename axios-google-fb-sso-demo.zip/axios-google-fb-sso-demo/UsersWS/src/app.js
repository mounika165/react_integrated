const express = require('express');
const app = express();
const router = require('./routes/routing');
const bodyParser = require('body-parser');
const cors = require('cors');
const errorLogger = require('./utilities/errorLogger')
app.use(cors());
app.use(bodyParser.json());
app.use('/', router)
app.use(errorLogger);

app.listen(2500, () => {
    console.log("server stated @ port 2500")
})

