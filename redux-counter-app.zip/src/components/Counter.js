import React, { Component } from 'react'
import { connect } from 'react-redux';
import actionCreatorObj from '../actions/actions';
export class Counter extends Component {
    constructor(props) {
        super(props)
    }
    incrementCounter = () => {
        let actionObj = actionCreatorObj.incrementCounter()
        this.props.dispatch(actionObj);
    }
    decrementCounter = () => {
        let actionObj = actionCreatorObj.decrementCounter()
        this.props.dispatch(actionObj);
    }
    render() {
        return (
            <div className="mt-5">
                <h1>counter from route parameter:  {this.props.parameterCounter}</h1>
                <h1 className="text text-success mb-4">Counter App</h1>
                <button disabled={!this.props.counter} className="btn btn-outline-danger btn-lg mr-3" onClick={this.decrementCounter}>
                    -
                </button>
                <span style={{ fontSize: "30px" }}>{this.props.counter}</span>
                <button className="btn btn-outline-success btn-lg ml-3" onClick={this.incrementCounter}>
                    +
                </button>
            </div>
        )
    }
}
let mapStateToProps = (state, ownProps) => {
    return {
        counter: state.counter,
        parameterCounter: ownProps.match.params.CounterValue
    }
}

export default connect(mapStateToProps)(Counter);