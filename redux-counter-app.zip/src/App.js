import React from 'react';
// import logo from './logo.svg';
import './App.css';
import Counter from './components/Counter';
import { connect } from 'react-redux';
import actionCreatorObj from './actions/actions';
import { BrowserRouter, Route } from 'react-router-dom';

function App(props) {
  return (
    <div className="App">
      <BrowserRouter>
        <Route path={'/showCounter/:CounterValue'} component={Counter} />
      </BrowserRouter>
      {/* <Counter /> */}
      <div className="border border-success mr-5 ml-5 mt-4">
        <button onClick={() => props.dispatch(actionCreatorObj.incrementCounter())} className="btn btn-outline-primary mt-2">INCREASE</button>
        <h1>Counter value changed by Counter component: {props.counter}</h1>
      </div>
    </div>
  );
}

let mapStateToProps = (state) => {
  return {
    counter: state.counter
  }
}

export default connect(mapStateToProps)(App);