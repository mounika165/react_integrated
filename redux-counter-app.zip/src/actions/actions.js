let actionCreatorObj = {}

actionCreatorObj.incrementCounter = () => {
    return { type: 'INCREMENT_COUNTER' }
}
actionCreatorObj.decrementCounter = () => {
    return { type: 'DECREMENT_COUNTER' }
}

export default actionCreatorObj;