const express = require('express');
const router = express.Router();
const usersService = require('../service/users');
const setupdb = require('../model/setupdb').setupDB;

router.get('/setupDB', (req, res, next) => {
    setupdb().then(messageObj => {
        res.json(messageObj)
    }).catch(err => next(err))
})

router.get('/getAllProducts', (req, res, next) => {
    usersService.getAllProducts().then(productsArray => {
        res.json(productsArray)
    }).catch(err => next(err))
})

router.get('/login/:email', (req, res, next) => {
    let email = req.params.email
    usersService.getUserByEmail(email).then(userData => {
        res.json(userData)
    }).catch(err => next(err))
})

module.exports = router;