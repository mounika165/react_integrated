const cartDB = require('../model/users');

const cartService = {}

cartService.getAllProducts = () => {
    return cartDB.getAllProducts().then(productsArray => {
        if (productsArray) return productsArray
        else {
            let err = new Error('No Products Found!!')
            err.status = 404;
            throw err;
        }
    })
}

cartService.getUserByEmail = (email) => {
    return cartDB.getUserByEmail(email).then(userData => {
        if (userData) return userData
        else {
            let err = new Error(`No Users Found with email ${email} !!`)
            err.status = 404;
            throw err;
        }
    })
}

module.exports = cartService;