const connection = require('./connection');

const cartDB = {}

cartDB.getAllProducts = () => {
    return connection.getProductsCollection().then(productsModel => {
        return productsModel.find().then(productsArray => {
            if (productsArray.length) return productsArray
            else return null
        })
    })
}

cartDB.getUserByEmail = (email) => {
    return connection.getUsersCollection().then(userModel => {
        return userModel.findOne({ email: email }).then(userData => {
            if (userData) return userData
            else return null
        })
    })
}

module.exports = cartDB