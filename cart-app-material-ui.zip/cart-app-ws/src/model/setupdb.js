const connection = require('./connection');

usersData = [
    {
        email: "john@gmail.com",
        password: "John@123"
    },
    {
        email: "jack@gmail.com",
        password: "Jack@123"
    }
]

productData = [
    { pImgUrl: "/assets/iphone.jpg", pName: 'Iphone 7s', pPrice: 40000 },
    { pImgUrl: "/assets/nokiasmartphone.png", pName: 'Nokia 8', pPrice: 24000 },
    { pImgUrl: "/assets/redminote8.png", pName: 'Redmi Note 8', pPrice: 17000 },
    { pImgUrl: "/assets/samsunggalaxy.jpg", pName: 'Samsung Galaxy', pPrice: 30000 }
]


exports.setupDB = () => {
    return connection.getUsersCollection().then(userModel => {
        return userModel.deleteMany({}).then(deleted => {
            return userModel.insertMany(usersData).then(insertedUsers => {
                if (insertedUsers.length) {
                    return connection.getProductsCollection().then(producstModel => {
                        return producstModel.deleteMany({}).then(productsdeleted => {
                            return producstModel.insertMany(productData).then(insertedProducts => {
                                if (insertedProducts.length) return { "message": "Insertion Successfull" }
                                else throw new Error("setupdb failed")
                            })
                        })
                    })
                }
                else throw new Error("setupdb failed")
            })
        })
    })
}