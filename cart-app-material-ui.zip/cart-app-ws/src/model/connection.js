const mongoose = require('mongoose');

usersSchema = mongoose.Schema({
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true }
})

productsSchema = mongoose.Schema({
    pImgUrl: { type: String, required: true },
    pName: { type: String, required: true, unique: true },
    pPrice: { type: Number, required: true }
})

let connection = {}

mongoose.set('useCreateIndex', true)

connection.getUsersCollection = () => {
    return mongoose.connect("mongodb://localhost:27017/CartAppDB", { useNewUrlParser: true, useUnifiedTopology: true }).then(db => {
        return mongoose.model('Users', usersSchema)
    }).catch(error => {
        let err = new Error("Could not connect to database");
        err.status = 500;
        throw err;
    })
}

connection.getProductsCollection = () => {
    return mongoose.connect("mongodb://localhost:27017/CartAppDB", { useNewUrlParser: true, useUnifiedTopology: true }).then(db => {
        return mongoose.model('Products', productsSchema)
    }).catch(error => {
        let err = new Error("Could not connect to database");
        err.status = 500;
        throw err;
    })
}

module.exports = connection;