import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import { BrowserRouter, Route, Switch, Redirect } from 'react-router-dom';
import Login from './components/Login';
import PageNotFound from './components/PageNotFound';
import ProductList from './components/ProductList';
import Cart from './components/Cart';
const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
  },
  menuButton: {
    marginRight: theme.spacing(2),
  },
}));

export default function App() {
  const classes = useStyles();

  return (
    <div className={classes.root}>
      <AppBar position="static">
        <Toolbar variant="dense">
          <Typography variant="h6" color="inherit">
            {/* <Link className="ml-auto" to="/login" >Login</Link> */}
              Cart App
            </Typography>
        </Toolbar>
      </AppBar>
      <BrowserRouter>
        <Switch>
          <Route exact path="/" render={() => <Redirect to="/login" />} />
          <Route exact path="/login" component={Login} />
          <Route exact path="/products" component={ProductList} />
          <Route exact path="/cart" component={Cart} />
          <Route exact path="/pagenotfound" component={PageNotFound} />
          <Route path="*" render={() => <Redirect to="/pagenotfound" />} />
        </Switch>
      </BrowserRouter>
    </div>
  );
}












// import React from 'react';
// import logo from './logo.svg';
// import './App.css';
// import Login from './components/Login';
// import PageNotFound from './components/PageNotFound';
// import AppBar from '@material-ui/core/AppBar';
// import Toolbar from '@material-ui/core/Toolbar';
// import Typography from '@material-ui/core/Typography';

// function App() {
//   return (
//     // <div className="App">
//     <BrowserRouter>
//       <AppBar >
//         <Toolbar>
//           <Typography variant="h6" color="inherit" noWrap >
//             <Link to='/dashboard' exact={"true"}>Cart App</Link>
//           </Typography>
//           <Link className="ml-auto" to="/login" >Login</Link>
//         </Toolbar>
//       </AppBar>
//       <Switch>
//         <Route exact path="/" render={() => <Redirect to="/login" />} />
//         <Route exact path="/login" component={Login} />
//         <Route exact path="/pagenotfound" component={PageNotFound} />
//         <Route exact path="*" render={() => <Redirect to="/pagenotfound" />} />
//       </Switch>

//     </BrowserRouter>
//     // </div>
//   );
// }

// export default App;
