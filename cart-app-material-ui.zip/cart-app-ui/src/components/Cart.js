import React, { Component, Fragment } from 'react'
import Grid from '@material-ui/core/Grid';
import { makeStyles, withStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import { Box } from '@material-ui/core';
import Button from '@material-ui/core/Button';

const useStyles = makeStyles({
    table: {
        minWidth: 650,
    },
});


export class Cart extends Component {

    constructor(props) {
        super(props)

        this.state = {
            cartArray: this.props.location.state.cartData,
            totalBill: this.props.location.state.totalBill,
            totalQuantity: this.props.location.state.totalQuantity
        }
    }


    render() {
        // return "hello"
        const { classes } = this.props;
        const { cartArray } = this.state;
        return (
            <div className="mt-5">
                <Grid container spacing={2} justify="center">
                    <Grid item xs={8} sm={8} lg={8}>
                        <Box boxShadow={10} bgcolor="background.paper" m={1} p={1}>
                            {
                                this.state.cartArray.length ?
                                    <Fragment>
                                        <h1 style={{ fontFamily: "cursive", textAlign: "center" }} className="text text-success">Your Cart has {cartArray.length} Product(s)</h1>
                                        <TableContainer component={Paper}>
                                            <Table className={classes.table} aria-label="cart table">
                                                <TableHead>
                                                    <TableRow>
                                                        <TableCell>Product Name</TableCell>
                                                        <TableCell align="right">Product Quantity</TableCell>
                                                        <TableCell align="right">Price (per Unit)</TableCell>
                                                        <TableCell align="right">Total Price</TableCell>
                                                    </TableRow>
                                                </TableHead>
                                                <TableBody>
                                                    {
                                                        this.state.cartArray.map((product, index) => (
                                                            <TableRow key={index}>
                                                                <TableCell component="th" scope="row">
                                                                    {product.pName}
                                                                </TableCell>
                                                                <TableCell align="right">{product.quantity}</TableCell>
                                                                <TableCell align="right">{product.pPrice}</TableCell>
                                                                <TableCell align="right">{product.pPrice * product.quantity}</TableCell>
                                                            </TableRow>
                                                        ))
                                                    }
                                                    <TableRow key={"footer"}>
                                                        <TableCell component="th" scope="row">
                                                        </TableCell>
                                                        <TableCell align="right"><h5>Total Quantity: {this.state.totalQuantity}</h5></TableCell>
                                                        <TableCell align="right"></TableCell>
                                                        <TableCell align="right"><h5>Total Bill: ₹ {this.state.totalBill}</h5></TableCell>
                                                    </TableRow>
                                                </TableBody>
                                            </Table>
                                        </TableContainer>
                                    </Fragment> :
                                    <div className="text-center">
                                        <img src="/assets/cart_empty.PNG" alt="empty cart" />
                                    </div>
                            }
                            <div style={{ textAlign: "center" }}>
                                <Button style={{ marginTop: "20px" }} onClick={() => this.props.history.push('/products')} variant="contained" color="primary" className={classes.button} >
                                    Continue Shopping
                                </Button>
                            </div>
                        </Box>
                    </Grid>
                </Grid>
            </div>
        )
    }
}

export default withStyles(useStyles)(Cart);
