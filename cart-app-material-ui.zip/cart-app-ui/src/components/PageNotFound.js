import React, { Component } from 'react'

export class PageNotFound extends Component {
    render() {
        return (
            <div className="text-center mt-5">
                <img src="/assets/funny-404-page.jpg" alt="product not found" style={{ height: "500px", width:"800px" }} />
            </div>
        )
    }
}

export default PageNotFound
