import React, { Component } from 'react';
import axios from 'axios';
import { makeStyles, withStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import Input from '@material-ui/core/Input';
import InputLabel from '@material-ui/core/InputLabel';
import FormControl from '@material-ui/core/FormControl';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import { Box } from '@material-ui/core';


const useStyles = makeStyles((theme) => ({
    main: {
        width: 'auto',
        display: 'block', 
        marginLeft: theme.spacing(3),
        marginRight: theme.spacing(3),
        [theme.breakpoints.up(400 + theme.spacing(3) * 2)]: {
            width: 400,
            marginLeft: 'auto',
            marginRight: 'auto',
        },
    },
    paper: {
        marginTop: theme.spacing(8),
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        padding: `${theme.spacing(2)}px ${theme.spacing(3)}px ${theme.spacing(3)}px`,
    },
    avatar: {
        margin: theme.spacing(1),
        backgroundColor: theme.palette.secondary.main,
    },
    form: {
        width: '100%', 
        marginTop: theme.spacing(1),
    },
    submit: {
        marginTop: theme.spacing(3),
    },
}));

class Login extends Component {

    constructor(props) {
        super(props)

        this.state = {
            loginForm: {
                email: '',
                password: ''
            },
            loginFormError: {
                email: '',
                password: '',
            },
            loginFormValid: {
                email: false,
                password: false,
                buttonActive: false
            },
            errorMessage: ""
        }
    }


    handleChange = (event) => {
        let name = event.target.name;
        let value = event.target.value;
        const { loginForm } = this.state;
        this.setState({ loginForm: { ...loginForm, [name]: value } }, () => {
            this.validateField(name, value)
        })
    };

    validateField = (fieldName, value) => {
        let message;
        let { loginFormError } = this.state;
        let { loginFormValid } = this.state;

        switch (fieldName) {
            case 'email':
                let emailRegex = new RegExp(/^[A-z][A-z0-9.]+@[a-z]+\.[a-z]{2,3}$/);
                value === "" ? message = "Please enter your email id" : emailRegex.test(value) ? message = "" : message = "Email id format is wrong"
                break;

            case "password":
                let passRegex = new RegExp(/^(?=.*[A-Z])(?=.*[!@#$&*%&])(?=.*[0-9])(?=.*[a-z]).{7,20}$/);
                value === "" ? message = "Please enter your password" : passRegex.test(value) ? message = "" : message = "Invalid password"
                break

            default:
                break;
        }
        loginFormError[fieldName] = message;
        message === "" ? loginFormValid[fieldName] = true : loginFormValid[fieldName] = false;
        loginFormValid.buttonActive = loginFormValid.email && loginFormValid.password;
        this.setState({ loginFormError: loginFormError, loginFormValid: loginFormValid });
    }

    loginUser = (event) => {
        event.preventDefault();
        axios.get(`http://localhost:2500/login/${this.state.loginForm.email}`).then(response => {
            if (response.data.password === this.state.loginForm.password) {
                this.props.history.push('/products')
            } else {
                this.setState({ errorMessage: "Invalid Credentials" })
            }
        }).catch(error => {
            if (error.response) {
                this.setState({ errorMessage: error.response.data.message })
            } else {
                this.setState({ errorMessage: error.message })
            }
        })
    }


    render() {
        const { email, password } = this.state.loginForm;
        const { loginFormError } = this.state;
        const { classes } = this.props;
        return (
            <div className={this.props.root} style={{ marginTop: "60px" }}>
                <Grid container spacing={3} justify="center">
                    <Grid item xs={12} sm={6}>
                        <Box boxShadow={10} bgcolor="background.paper" m={1} p={1}>
                            <CardContent>
                                <Typography component="h1" variant="h5">
                                    Please login to continue
                                </Typography>
                                <form className={classes.form} onSubmit={this.loginUser}>
                                    <div className="text text-center">
                                        <FormControl margin="normal" required fullWidth>
                                            <InputLabel htmlFor="uemail">Email address</InputLabel>
                                            <Input autoComplete="email" autoFocus
                                                id="uemail" name="email"
                                                value={email} onChange={this.handleChange} />
                                            <span className="text-danger">{loginFormError.email}</span>
                                        </FormControl>

                                        <FormControl margin="normal" required fullWidth>
                                            <InputLabel htmlFor="uPass">Password</InputLabel>
                                            <Input name="password" type="password" value={password}
                                                onChange={this.handleChange} id="uPass"
                                                autoComplete="current-password" />
                                            <span className="text-danger">{loginFormError.password}</span><br />
                                        </FormControl>

                                        <Button type="submit" variant="contained" color="primary" className={classes.submit} disabled={!this.state.loginFormValid.buttonActive}>
                                            Login
                                        </Button>
                                    </div>
                                </form>
                                <div className="text text-center text-danger mt-2">{this.state.errorMessage}</div>
                            </CardContent>
                        </Box>
                    </Grid>
                </Grid>
            </div >
        );

    }
}

export default withStyles(useStyles)(Login);