import React, { Component } from 'react'
import Axios from 'axios'
import { makeStyles, withStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
// import CardMedia from '@material-ui/core/CardMedia';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
// import Icon from '@material-ui/core/Icon';
import ShoppingCartIcon from '@material-ui/icons/ShoppingCart';
// import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import CircularProgress from '@material-ui/core/CircularProgress';

const useStyles = makeStyles((theme) => ({
    root: {
        maxWidth: 245,
        flexGrow: 1,
        display: 'flex',
        '& > * + *': {
            marginLeft: theme.spacing(2),
        },
    },
    media: {
        height: 100,
    },
    paper: {
        padding: theme.spacing(2),
        textAlign: 'center',
        color: theme.palette.text.secondary,
    },
}));

export class ProductList extends Component {

    constructor(props) {
        super(props)

        this.state = {
            productsArray: [],
            errorMessage: "",
            cartData: [],
            showCart: false,
            totalBill: 0,
            totalQuantity: 0
        }
    }

    componentDidMount() {
        Axios.get("http://localhost:2500/getAllProducts").then(response => {
            this.setState({ productsArray: response.data })
        }).catch(error => {
            if (error.response) {
                this.setState({ errorMessage: error.response.data.message })
            } else {
                this.setState({ errorMessage: error.message })
            }
        })
    }

    addToCart = (product) => {
        let totalBill = 0;
        let totalQuantity = 0;
        const { cartData } = this.state;
        let availableArray = cartData.filter(cartItem => cartItem.pName === product.pName)
        if (availableArray.length) {
            cartData.forEach(cartItem => {
                if (cartItem.pName === product.pName) cartItem.quantity += 1
            })
        } else {
            product.quantity = 1
            cartData.push(product);
        }
        cartData.map(cartItem => {
            totalBill += cartItem.quantity * cartItem.pPrice;
            totalQuantity += cartItem.quantity
            return ""
        })
        this.setState({ cartData: cartData, totalBill: totalBill, totalQuantity: totalQuantity }, () => {
            console.log(cartData);
        })
    }

    goToCart = () => {
        const { cartData, totalBill, totalQuantity } = this.state;
        this.props.history.push('/cart', { cartData: cartData, totalBill: totalBill, totalQuantity: totalQuantity })
    }

    render() {
        const { classes } = this.props;
        return (
            <div className="mt-5">
                <Grid container spacing={2}>
                    {
                        this.state.productsArray ? this.state.productsArray.map((product, index) => {
                            return (
                                <Grid item xs={6} sm={3} key={index} >
                                    <Card className={classes.root} style={{
                                        display: 'block',
                                        width: '300px',
                                    }}>
                                        <CardActionArea>
                                            <img src={product.pImgUrl} alt={product.pName} />
                                            <CardContent>
                                                <Typography style={{ fontFamily: "cursive" }} gutterBottom variant="h5" component="h2">
                                                    {product.pName}
                                                </Typography>
                                                <Typography style={{ fontFamily: "cursive" }} variant="h6" component="h4" >
                                                    Price: <span style={{ color: "green" }}>₹ {product.pPrice}</span>
                                                </Typography>
                                            </CardContent>
                                        </CardActionArea>
                                        <CardActions>
                                            <Button onClick={() => this.addToCart(product)} variant="contained" color="primary" className={classes.button} endIcon={<ShoppingCartIcon></ShoppingCartIcon>}>
                                                Add to Cart
                                            </Button>
                                        </CardActions>
                                    </Card>
                                </Grid>
                            )
                        }) : <CircularProgress />
                    }
                </Grid>
                <div className="mt-5 text-center">
                    <Button onClick={this.goToCart} variant="outlined" color="primary" className={classes.button} endIcon={<ShoppingCartIcon></ShoppingCartIcon>}>
                        Go To Cart
                    </Button>
                </div>
            </div>
        )
    }
}

export default withStyles(useStyles)(ProductList);


// export default connect(mapStateToProps)(withStyles(useStyles)(ProductList))